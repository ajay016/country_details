from django.apps import AppConfig


class CountryInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'country_info'
